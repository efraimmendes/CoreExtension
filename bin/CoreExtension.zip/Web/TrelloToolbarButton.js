﻿
window.TrelloUI = window.TrelloUI || {};
(function (window) {
    var self = this;
    this.Id = "";
    this.Titulo = "";
    this.BtnHtml = "";
    this.onClick = null;
    var trelloToolbarButton = function(data) {
        self.Id = data ? data.Id : 0;
        self.Titulo = data ? data.Titulo : "";
        self.BtnHtml = data ? data.BtnHtml : "";
        self.onClick = data ? data.onClick : null;
    }
    trelloToolbarButton.prototype.GetHtmlButton = function () {
        self.BtnHtml = "<div class=\"u-clearfix\"> <a " + self.Id + " onclick=" + self.onClick + "class=\"button-link \" href=\"#\">" +
            "<span class=\"icon-sm icon-clock\"></span> <span id=\"btnText\">" + self.Titulo + "</span></a>" +
            "</div>";
    }
    window.TrelloUI.TrelloToolBarButton = trelloToolbarButton;
})(window)
﻿window.TrelloUI = window.TrelloUI || {};
(function (window) {
    var self = this;
    this.Id = "";
    this.ListButton = [];
    var trelloToolbar = function (id, titulo, divInsertBefore) {
        self.Id = id;
        var divId = id != null ? "id=" + id : "";
        var divH3 = titulo != null ? "<h3>" + titulo + "</h3>" : "";

        var strBar = "<div " + divId + " class=\"window-module u-clearfix\">" +
            divH3 +
            "<div id=\"toolbarButtonList\">"
            "</div>";
        $(strBar).insertBefore(divInsertBefore.firstChild);
    }
    function renderizeButtons() {
        $("#toolbarButtonList").empty();
        ListButton.forEach(function (item) {
            var btn = new window.TrelloUI.TrelloToolBarButton(item);
            $("#toolbarButtonList").append(btn.GetHtmlButton());
        });
    }
    trelloToolbar.prototype.AddButton = function(toolbarButton) {
        self.ListButton.push(toolbarButton);
        renderizeButtons();
    }
    trelloToolbar.prototype.RemoveButton = function (toolbarButton) {
        self.ListButton.push(toolbarButton);
        renderizeButtons();
    }
    window.TrelloUI.TrelloToolBar = trelloToolbar;
})(window);

